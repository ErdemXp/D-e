# web download bot

A Telegram bot to scrape and download all the components (.html, .css, img, xml, video, javascript..) from the URLs and send to you as an zip archive.


## Deploy to Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/samadii/WebDownloaderBot)
