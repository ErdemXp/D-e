import os
import shutil
from web_dl import urlDownloader
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

BOT_TOKEN = "6700793810:AAGNRhRQ_vzvqZXXuprrCX1XoUMSfJB0zA0"
API_ID = 22414322
API_HASH = "d4ae0d06f838826fbcf1fa2dbe6b8f91"

Bot = Client(
    "WebDL-Bot",
    bot_token = BOT_TOKEN,
    api_id = API_ID,
    api_hash = API_HASH
)

START_TXT = """
Merhaba {}, ben Web Downloader Bot'um.

URL'lerden tüm dosyaları (.html, .css, img, xml, video, javascript..) indirebiliyorum.

Herhangi bir URL'yi gönderin,
örneğin: 'https://www.google.com'
"""

START_BTN = InlineKeyboardMarkup(
        [[
        InlineKeyboardButton('Sahip 💪🦾', url='https://t.me/proluciofficial'),
        ]]
    )


@Bot.on_message(filters.command(["start"]))
async def start(bot, update):
    text = START_TXT.format(update.from_user.mention)
    reply_markup = START_BTN
    await update.reply_text(
        text=text,
        disable_web_page_preview=True,
        reply_markup=reply_markup
    )




@Bot.on_message(filters.private & filters.text & ~filters.regex('/start'))
async def webdl(_, m):

    if not m.text.startswith('http'):
        return await m.reply("URL 'http' veya 'https' ile başlamalıdır")

    msg = await m.reply('İşleniyor..')
    url = m.text
    name = dir = str(m.chat.id)
    if not os.path.isdir(dir):
        os.makedirs(dir)

    obj = urlDownloader(imgFlg=True, linkFlg=True, scriptFlg=True)
    res = obj.savePage(url, dir)
    if not res:
        return await msg.edit('bir şeyler ters gitti!')

    shutil.make_archive(name, 'zip', base_dir=dir)
    await m.reply_document(name+'.zip')
    await msg.delete()

    shutil.rmtree(dir)
    os.remove(name+'.zip')



Bot.run()
